// widgets/score_display.dart

import 'package:flutter/material.dart';

class ScoreDisplay extends StatelessWidget {
  final int score;

  const ScoreDisplay({required this.score, super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0, bottom: 40.0),
      child: Text(
        'Score: $score',
        style: Theme.of(context).textTheme.headline4,
      ),
    );
  }
}
